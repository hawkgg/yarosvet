<?php
/*
Plugin Name: Marketing Demo Importer
Plugin URI: http://themebubble.com
Description: Loads Demo for Marketing Pro theme.
Version: 1.0
Author: relstudiosnx
Author URI: http://themebubble.com
*/

// Replace {$redux_opt_name} with your opt_name.
// Also be sure to change this function name!
if(!function_exists('redux_register_custom_extension_loader_demo')) :
    function redux_register_custom_extension_loader_demo($ReduxFramework) {
      $path    = dirname( __FILE__ ) . '/extensions/';
      $folders = scandir( $path, 1 );
      foreach ( $folders as $folder ) {
        if ( $folder === '.' or $folder === '..' or ! is_dir( $path . $folder ) ) {
          continue;
        }
        $extension_class = 'ReduxFramework_Extension_' . $folder;
        if ( ! class_exists( $extension_class ) ) {
          $class_file = $path . $folder . '/extension_' . $folder . '.php';
          $class_file = apply_filters( 'redux/extension/' . $ReduxFramework->args['opt_name'] . '/' . $folder, $class_file );
          if ( $class_file ) {
            require_once( $class_file );
          }
        }
        if ( ! isset( $ReduxFramework->extensions[ $folder ] ) ) {
          $ReduxFramework->extensions[ $folder ] = new $extension_class( $ReduxFramework );
        }
      }
    }
    // Modify {$redux_opt_name} to match your opt_name
    add_action("redux/extensions/marketing_theme_options/before", 'redux_register_custom_extension_loader_demo', 0);
endif;
