<?php
/**
 * Index Page
 *
 * @package marketing
 * @since 1.0
 */
get_template_part('page-templates/blog-list');

